# Curso_HANA
Practicas del curso HANA
